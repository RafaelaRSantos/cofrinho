package empresa;

import java.util.Arrays;
import java.util.Objects;
//classe mae: 
abstract public class Moeda {
	
          double valor;
          Moeda(double valor){
        	  this.valor=valor;
          }

		abstract void info();{
	
          }
		
	          public Moeda[] listaMoeda;
	
	    public abstract double converter() ;
        
        public void calculaTotal() {
        	double total=0;
        	for( Moeda c : listaMoeda){
        		total +=c.converter();
        		System.out.println(total);
   		}
          
	  
  }

		@Override
		public int hashCode() {
			final int prime = 31;
			int result = 1;
			result = prime * result + Arrays.hashCode(listaMoeda);
			result = prime * result + Objects.hash(valor);
			return result;
		}

		@Override
		public boolean equals(Object obj) {
			if (this == obj)
				return true;
			if (obj == null)
				return false;
			if (getClass() != obj.getClass())
				return false;
			Moeda other = (Moeda) obj;
			return Arrays.equals(listaMoeda, other.listaMoeda)
					&& Double.doubleToLongBits(valor) == Double.doubleToLongBits(other.valor);
		}

	

		
    	
    }
     
        
   	

    	   
   	  
    
  
 