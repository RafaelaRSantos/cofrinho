package empresa;

import java.util.ArrayList;

public class Cofrinho {
	ArrayList<Moeda> listaMoeda = new ArrayList<Moeda>();
	
	
	
	public void adicionar(Object moeda) {
		listaMoeda.add((Moeda) moeda);
	}
	 public void remover(Object moeda) {
		 listaMoeda.remove(moeda);
		 System.out.println("moeda removida com sucesso");
	}
	 
	 public void totalConvertido() {
		 for (Moeda c :listaMoeda)
			 System.out.println(c);
	 }
	 
	public void listaMoeda() {
		for(Moeda c : listaMoeda)
			System.out.print(c);
		
	}
	
        
	}
