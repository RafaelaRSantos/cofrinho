package empresa;

import java.util.Objects;

public class Dolar extends Moeda {
	
	Dolar(double valor) {
		super(valor);
		// TODO Auto-generated constructor stub
	}
	private double Moeda;
	@Override
	void info() {
		System.out.println("Real" + valor);
		
	}
	
       public double converter() {
		 return valor * 5;
	}
	
       double calculaValor () {
   	 
	 
	    double total = 5*valor;
   	    return total;
}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = super.hashCode();
		result = prime * result + Objects.hash(Moeda);
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!super.equals(obj))
			return false;
		if (getClass() != obj.getClass())
			return false;
		Dolar other = (Dolar) obj;
		return Moeda == other.Moeda;
	}

	@Override
	public String toString() {
		return "Dolar [Dolar = " + ", valor = " + valor + ", convertido = " + converter() + ", Valor = "
				+ calculaValor() + "]";
	}

	

	
	
	
	}


	

