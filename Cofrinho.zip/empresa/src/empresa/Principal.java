package empresa;

import java.util.Scanner;

public class Principal {

	public static void main(String... args) {
	
				
	   Scanner teclado = new Scanner(System.in);
		int opcao;       
	      
	       Cofrinho cofrinho = new Cofrinho();
	       System.out.println("Bem vindo ao cofrinho da Rafaela , RU: 3608802");
						
			System.out.println("Menu");
			System.out.println("1- Adicionar moedas");
			System.out.println("2- Remover");
			System.out.println("3- Listar moedas");
			System.out.println("4- converter em  reais");
			System.out.println("0- Encerrar");
			opcao=teclado.nextInt();
									
				int tipoMoeda= 0;
			   double valor = 0;
				
				while(opcao !=0) {		
				
			
				Moeda Moeda = null;
				
				switch(opcao) {
				case 1:
				    tipoMoeda =0 ;
				System.out.println("qual moeda deseja adicionar?");		
			    while(tipoMoeda>3 || tipoMoeda<=0){
			    System.out.println("1- Euro");
				System.out.println("2- Dolar");
				System.out.println("3- Real");
				tipoMoeda = teclado.nextInt();
			}		
					
					if(tipoMoeda==1) {
						System.out.println("Qual valor da moeda de Euro?");
						 valor = teclado.nextDouble();
						Moeda = new Euro(valor);
						
					}
					   if(tipoMoeda==2) {
					  System.out.println("Qual valor da moeda de Dolar?");
					  valor = teclado.nextDouble();
					      Moeda = new Dolar(valor );
					
					}
					   else
						   if(tipoMoeda==3){
					    	System.out.println("Qual valor da moeda Real?");
					    	valor = teclado.nextDouble();
					    	Moeda = new Real( valor);
							
					    }
					cofrinho.adicionar(Moeda);
					break;
				case 2:
					 tipoMoeda =0 ;
					System.out.println("qual moeda deseja remover?");	
					while(tipoMoeda>3 || tipoMoeda<=0){
				    System.out.println("1- Euro");
					System.out.println("2- Dolar");
					System.out.println("3- Real");
					tipoMoeda = teclado.nextInt();
					}
					if(tipoMoeda==1) {
						System.out.println("Qual valor da moeda de Euro?");
						valor = teclado.nextDouble();
						Moeda = new Euro(valor);
						
					}
					   if(tipoMoeda==2) {
					  System.out.println("Qual valor da moeda de Dolar?");
					  valor = teclado.nextDouble();
					  Moeda = new Dolar(valor );
					
					}
					   else
						   if(tipoMoeda==3){
					    	System.out.println("Qual valor da moeda Real?");
					    valor = teclado.nextDouble();
					    	 Moeda = new Real(valor);
					    	 
							break;
					    }
					
				    	cofrinho.remover(Moeda);
					break;
				case 3:
					
					cofrinho.listaMoeda();
					break;
				case 4:
					cofrinho.totalConvertido();
					break;
				case 0:
					break;
					default:
						
							System.out.println("opcao invalida!");
}		
								
				System.out.println("Menu");
				System.out.println("1- Adicionar moedas");
				System.out.println("2- Remover");
				System.out.println("3- Listar moedas");
				System.out.println("4- Converter em reais");
				System.out.println("0- Encerrar");
				opcao=teclado.nextInt();		
	}																		
}		
}