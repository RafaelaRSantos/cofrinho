package empresa;

import java.util.Objects;
//classe filha3
public class Real extends Moeda{

	Real(double valor) {
		super(valor);
		// TODO Auto-generated constructor stub
	}
	private double Moeda;

@Override
	void info() {
		System.out.println("Real" + valor);
		
	}
	

	@Override
	public double converter() {
		return valor * 1;
	}
	
         double calculaValor () { 
		double total = 1 * valor;
        	 return total;
			
	
         }

		@Override
		public int hashCode() {
			final int prime = 31;
			int result = super.hashCode();
			result = prime * result + Objects.hash(Moeda);
			return result;
		}


		@Override
		public boolean equals(Object obj) {
			if (this == obj)
				return true;
			if (!super.equals(obj))
				return false;
			if (getClass() != obj.getClass())
				return false;
			Real other = (Real) obj;
			return Double.doubleToLongBits(Moeda) == Double.doubleToLongBits(other.Moeda);
		}


		@Override
		public String toString() {
			return "Real [Real = "  + ", valor = " + valor + ", convertido = " + converter() + ", total = "
					+ calculaValor() + " ] " ;
		}


		

}
	


